# JXT - Junior Table

Astax Studio tarafından geliştirilen Türkçe veritabanı sistemi.

## Endpoints

### OLUŞTUR
```
POST /olustur
{"tablo": "kullanicilar", "sutunlar": {"isim": "METİN", "yas": "SAYI"}}
```

### EKLE
```
POST /ekle
{"tablo": "kullanicilar", "satir": {"isim": "Ahmet", "yas": 25}}
```

### AL
```
GET /al?tablo=kullanicilar
GET /al?tablo=kullanicilar&sart_sutun=yas&sart_deger=25
```

### SİL
```
DELETE /sil
{"tablo": "kullanicilar", "sart_sutun": "isim", "sart_deger": "Ahmet"}
```

### GÜNCELLE
```
PUT /guncelle
{"tablo": "kullanicilar", "sart_sutun": "isim", "sart_deger": "Ahmet", "yeni": {"yas": 26}}
```
